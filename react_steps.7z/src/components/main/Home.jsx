export default function Home() {
  return (
    <div className="home">
        <h1>Main Page</h1>
    </div>
  )
}
